declare module "@ckeditor/ckeditor5-build-classic";
declare module "@ckeditor/ckeditor5-build-balloon-block";
declare module "@ckeditor/ckeditor5-build-balloon";
declare module "@ckeditor/ckeditor5-build-decoupled-document";
declare module "@ckeditor/ckeditor5-build-inline";
